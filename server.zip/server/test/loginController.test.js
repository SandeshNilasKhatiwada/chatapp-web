const request = require("supertest");
const jwt = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const mongoose = require("mongoose");
const { app, startServer, closeServer, close_db } = require("../index"); // Import server functions
const User = require("../Models/userModel");

// ✅ Mock User Model
jest.mock("../models/userModel");

describe("User Login API", () => {
  beforeAll(() => {
    startServer();
  });

  afterAll(async () => {
    await close_db(); // Close MongoDB
    closeServer(); // Close Express server
  });

  it("should login successfully with valid credentials", async () => {
    // ✅ Mock user data
    const mockUser = {
      name: "jonny",
      password: await bcrypt.hash("sandesh", 10), // Hashed password
    };

    // ✅ Mock User.findOne to return the user
    User.findOne.mockResolvedValue(mockUser);

    // ✅ Mock bcrypt.compare to return true (valid password)
    bcrypt.compare = jest.fn().mockResolvedValue(true);

    // ✅ Mock jwt.sign
    jwt.sign = jest.fn().mockReturnValue("mocked_token");

    // ✅ Send login request
    const res = await request(app)
      .post("/user/login") // Change the endpoint if needed
      .send({ email: "test@example.com", password: "password123" });

    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty("token", "mocked_token");
    expect(res.body.message).toBe("Login successful");
  });

  it("should return 401 for invalid credentials", async () => {
    User.findOne.mockResolvedValue(null);

    const res = await request(app)
      .post("/user/login")
      .send({ email: "wrong@example.com", password: "wrongpassword" });

    expect(res.status).toBe(401);
    expect(res.body.error).toBe("Invalid credentials");
  });

  it("should return 401 if password is incorrect", async () => {
    const mockUser = {
      _id: new mongoose.Types.ObjectId(),
      email: "test@example.com",
      password: await bcrypt.hash("password123", 10),
    };

    User.findOne.mockResolvedValue(mockUser);
    bcrypt.compare = jest.fn().mockResolvedValue(false); // Simulate wrong password

    const res = await request(app)
      .post("/user/login")
      .send({ email: "test@example.com", password: "wrongpassword" });

    expect(res.status).toBe(401);
    expect(res.body.error).toBe("Invalid credentials");
  });
});
